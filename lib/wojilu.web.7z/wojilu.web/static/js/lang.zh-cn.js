﻿var lang = {};

lang.exop = '操作错误';
lang.deleteTip = '确实要删除？';
lang.deleteTrueTip = '确实要删除？本删除是彻底删除，不可恢复。';
lang.deleteCategory = '确实要删除？本删除是彻底删除，不可恢复。\n如果删除，当前分类下面的所有数据将自动进入回收站';

lang.del = '删除';

lang.closeBox = '关闭窗口';
lang.loading = '加载中……';

lang.boxTitle = '对话窗口';

lang.exUrl= '无网址';

lang.exDrag='sorry...拖动布局无法保存';

lang.exSelect='请先选择';
lang.exFill='请填写';

lang.exLogin='请先登录';
lang.exAddSelf = '不可以添加自己';
lang.addFriendOk='添加好友成功';
lang.hasBeenFriend='已经是好友';

